<script setup>
</script>
<template>
    <div class="container">
        <h1>Bienvenido al DashBoard xD</h1>
    </div>
</template>
<style scoped>
.container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}
</style>